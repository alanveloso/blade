// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
import {ContractNetManager} from "../src/core/ContractNetManager.sol";
import {Agent} from "../src/core/Agent.sol";
import {Message} from "../src/core/Message.sol";
import {Performative} from "../src/core/Performative.sol";
import {Protocol} from "../src/core/Protocol.sol";

/// @notice Research candidate: stages decisions, delivers each in a separate call.
/// @dev Not a production replacement. Owner chooses decisions; anyone can trigger delivery.
/// A stuck recipient retains its queue entry and prevents ID reuse, but not honest delivery.
contract QueuedContractNetManager is ContractNetManager {
    address public immutable owner;
    mapping(bytes32 => mapping(address => uint8)) public pending;
    mapping(bytes32 => uint256) public pendingCount;
    event DecisionQueued(bytes32 indexed id, address indexed peer, uint8 act);

    constructor() Agent(address(0)) {
        owner = msg.sender;
    }
    modifier onlyOwner() {
        require(msg.sender == owner, "owner");
        _;
    }

    function cfp(address[] calldata peers, Message memory m) external onlyOwner {
        require(pendingCount[m.conversationId] == 0, "pending decisions");
        _cfp(peers, m);
    }

    function evaluate(
        bytes32 id,
        address[] calldata accept,
        address[] calldata reject,
        address[] calldata silent
    ) external onlyOwner {
        _evaluate(id, accept, reject, silent);
    }

    function deliver(bytes32 id, address peer) external {
        uint8 act = pending[id][peer];
        require(act != 0, "no decision");
        delete pending[id][peer];
        --pendingCount[id];
        super._send(peer, _act(id, act, 0));
    }

    function _send(address peer, Message memory m) internal override {
        if (
            m.protocol == uint8(Protocol.FipaContractNet)
                && (m.performative == uint8(Performative.AcceptProposal)
                    || m.performative == uint8(Performative.RejectProposal))
        ) {
            require(pending[m.conversationId][peer] == 0, "duplicate decision");
            pending[m.conversationId][peer] = m.performative;
            ++pendingCount[m.conversationId];
            emit DecisionQueued(m.conversationId, peer, m.performative);
        } else {
            super._send(peer, m);
        }
    }
}
